import cv2
import numpy as np

def espelhar_matriz(matriz):
    num_linhas = len(matriz)
    num_colunas = len(matriz[0])

    nova_matriz = [[0 for j in range(num_colunas)] for i in range(num_linhas)]

    for i in range(num_linhas):
        for j in range(num_colunas-1, -1, -1):
            nova_matriz[i][num_colunas-1-j] = matriz[i][j]

    return nova_matriz

imagem = cv2.imread("images/test-icon-01.png")
imagem_invertida = np.array(espelhar_matriz(imagem))

cv2.imwrite('images/invertida.png', imagem_invertida)

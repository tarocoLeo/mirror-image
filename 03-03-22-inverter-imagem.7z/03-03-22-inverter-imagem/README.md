# Espelhamento de Imagens

Criar uma sistema que leia uma imagem, transforme-a em uma matriz, realize o espelhamento e salve a imagem modificada.

Pode usar uma biblioteca para abrir a imagem em uma matriz e mostrar a matriz como imagem.

---

#### Instruções para rodar o projeto

- Instale as dependências `numpy` e `python-opencv`:
  ```
  pip install numpy
  pip install python-opencv
  ```
- Rode o arquivo `main.py`:
  ```
  python main.py
  ```
- Deve gerar uma imagem nomeada como `invertida.pn` dentro do diretório `images/`.

---

### Feito por:

Leonardo Taroco Santana
RA - 60776-2
BCC 7º Termo